﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Cart
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Cart))
        btnProfile3 = New PictureBox()
        btnNotification3 = New PictureBox()
        btnSearch3 = New PictureBox()
        btnCategory3 = New PictureBox()
        btnHome3 = New PictureBox()
        Label1 = New Label()
        Label2 = New Label()
        lblSubTotal = New Label()
        Label4 = New Label()
        lblDeliveryFee = New Label()
        Label6 = New Label()
        Label7 = New Label()
        Label3 = New Label()
        Label5 = New Label()
        Label8 = New Label()
        lblTotal = New Label()
        btnCheckout = New Button()
        PictureBox1 = New PictureBox()
        PictureBox2 = New PictureBox()
        PictureBox3 = New PictureBox()
        btnAddPink = New PictureBox()
        btnMinusPink = New PictureBox()
        btnAddWhite = New PictureBox()
        btnAddBlue = New PictureBox()
        btnMinusWhite = New PictureBox()
        btnMinusBlue = New PictureBox()
        lblPink = New Label()
        lblBlue = New Label()
        lblWhite = New Label()
        lblItemName1 = New Label()
        lblRM1 = New Label()
        lblPrice1 = New Label()
        lblItemName2 = New Label()
        lblRM2 = New Label()
        lblPrice2 = New Label()
        lblRM3 = New Label()
        lblItemName3 = New Label()
        lblPrice3 = New Label()
        CType(btnProfile3, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnNotification3, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnSearch3, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnCategory3, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnHome3, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnAddPink, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnMinusPink, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnAddWhite, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnAddBlue, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnMinusWhite, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnMinusBlue, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' btnProfile3
        ' 
        btnProfile3.BackColor = Color.Transparent
        btnProfile3.Image = CType(resources.GetObject("btnProfile3.Image"), Image)
        btnProfile3.Location = New Point(280, 591)
        btnProfile3.Name = "btnProfile3"
        btnProfile3.Size = New Size(56, 58)
        btnProfile3.SizeMode = PictureBoxSizeMode.Zoom
        btnProfile3.TabIndex = 27
        btnProfile3.TabStop = False
        ' 
        ' btnNotification3
        ' 
        btnNotification3.BackColor = Color.Transparent
        btnNotification3.Image = CType(resources.GetObject("btnNotification3.Image"), Image)
        btnNotification3.Location = New Point(218, 591)
        btnNotification3.Name = "btnNotification3"
        btnNotification3.Size = New Size(56, 58)
        btnNotification3.SizeMode = PictureBoxSizeMode.Zoom
        btnNotification3.TabIndex = 28
        btnNotification3.TabStop = False
        ' 
        ' btnSearch3
        ' 
        btnSearch3.BackColor = Color.Transparent
        btnSearch3.Image = CType(resources.GetObject("btnSearch3.Image"), Image)
        btnSearch3.Location = New Point(156, 591)
        btnSearch3.Name = "btnSearch3"
        btnSearch3.Size = New Size(56, 58)
        btnSearch3.SizeMode = PictureBoxSizeMode.Zoom
        btnSearch3.TabIndex = 29
        btnSearch3.TabStop = False
        ' 
        ' btnCategory3
        ' 
        btnCategory3.BackColor = Color.Transparent
        btnCategory3.Image = CType(resources.GetObject("btnCategory3.Image"), Image)
        btnCategory3.Location = New Point(94, 591)
        btnCategory3.Name = "btnCategory3"
        btnCategory3.Size = New Size(56, 58)
        btnCategory3.SizeMode = PictureBoxSizeMode.Zoom
        btnCategory3.TabIndex = 30
        btnCategory3.TabStop = False
        ' 
        ' btnHome3
        ' 
        btnHome3.BackColor = Color.Transparent
        btnHome3.Image = CType(resources.GetObject("btnHome3.Image"), Image)
        btnHome3.Location = New Point(32, 591)
        btnHome3.Name = "btnHome3"
        btnHome3.Size = New Size(56, 58)
        btnHome3.SizeMode = PictureBoxSizeMode.Zoom
        btnHome3.TabIndex = 26
        btnHome3.TabStop = False
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.Transparent
        Label1.Font = New Font("Rockwell", 12F, FontStyle.Bold)
        Label1.ForeColor = Color.RosyBrown
        Label1.Location = New Point(39, 364)
        Label1.Name = "Label1"
        Label1.Size = New Size(141, 19)
        Label1.TabIndex = 31
        Label1.Text = "Payment Details"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BackColor = Color.Transparent
        Label2.Font = New Font("Rockwell", 12F, FontStyle.Bold)
        Label2.Location = New Point(66, 402)
        Label2.Name = "Label2"
        Label2.Size = New Size(83, 19)
        Label2.TabIndex = 32
        Label2.Text = "Sub Total"
        ' 
        ' lblSubTotal
        ' 
        lblSubTotal.AutoSize = True
        lblSubTotal.BackColor = Color.Transparent
        lblSubTotal.Font = New Font("Rockwell", 12F, FontStyle.Bold)
        lblSubTotal.Location = New Point(222, 402)
        lblSubTotal.Name = "lblSubTotal"
        lblSubTotal.Size = New Size(0, 19)
        lblSubTotal.TabIndex = 33
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.BackColor = Color.Transparent
        Label4.Font = New Font("Rockwell", 12F, FontStyle.Bold)
        Label4.Location = New Point(40, 436)
        Label4.Name = "Label4"
        Label4.Size = New Size(110, 19)
        Label4.TabIndex = 34
        Label4.Text = "Delivery Fee"
        ' 
        ' lblDeliveryFee
        ' 
        lblDeliveryFee.AutoSize = True
        lblDeliveryFee.BackColor = Color.Transparent
        lblDeliveryFee.Font = New Font("Rockwell", 12F, FontStyle.Bold)
        lblDeliveryFee.Location = New Point(222, 436)
        lblDeliveryFee.Name = "lblDeliveryFee"
        lblDeliveryFee.Size = New Size(27, 19)
        lblDeliveryFee.TabIndex = 35
        lblDeliveryFee.Text = "10"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.BackColor = Color.Transparent
        Label6.Font = New Font("Rockwell", 12F, FontStyle.Bold)
        Label6.Location = New Point(178, 402)
        Label6.Name = "Label6"
        Label6.Size = New Size(38, 19)
        Label6.TabIndex = 36
        Label6.Text = "RM"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.BackColor = Color.Transparent
        Label7.Font = New Font("Rockwell", 12F, FontStyle.Bold)
        Label7.Location = New Point(178, 436)
        Label7.Name = "Label7"
        Label7.Size = New Size(38, 19)
        Label7.TabIndex = 37
        Label7.Text = "RM"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.BackColor = Color.Transparent
        Label3.Font = New Font("Rockwell", 12F, FontStyle.Bold)
        Label3.ForeColor = Color.RosyBrown
        Label3.Location = New Point(24, 25)
        Label3.Name = "Label3"
        Label3.Size = New Size(143, 19)
        Label3.TabIndex = 38
        Label3.Text = "Purchase Details"
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.BackColor = Color.Transparent
        Label5.Font = New Font("Rockwell", 12F, FontStyle.Bold)
        Label5.Location = New Point(94, 500)
        Label5.Name = "Label5"
        Label5.Size = New Size(50, 19)
        Label5.TabIndex = 39
        Label5.Text = "Total"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.BackColor = Color.Transparent
        Label8.Font = New Font("Rockwell", 12F, FontStyle.Bold)
        Label8.Location = New Point(178, 500)
        Label8.Name = "Label8"
        Label8.Size = New Size(38, 19)
        Label8.TabIndex = 40
        Label8.Text = "RM"
        ' 
        ' lblTotal
        ' 
        lblTotal.AutoSize = True
        lblTotal.BackColor = Color.Transparent
        lblTotal.Font = New Font("Rockwell", 12F, FontStyle.Bold)
        lblTotal.Location = New Point(222, 500)
        lblTotal.Name = "lblTotal"
        lblTotal.Size = New Size(0, 19)
        lblTotal.TabIndex = 41
        ' 
        ' btnCheckout
        ' 
        btnCheckout.BackColor = Color.Black
        btnCheckout.Font = New Font("STCaiyun", 11.9999981F, FontStyle.Regular, GraphicsUnit.Point, CByte(134))
        btnCheckout.ForeColor = SystemColors.Control
        btnCheckout.Location = New Point(94, 546)
        btnCheckout.Name = "btnCheckout"
        btnCheckout.Size = New Size(180, 39)
        btnCheckout.TabIndex = 42
        btnCheckout.Text = "Checkout"
        btnCheckout.UseVisualStyleBackColor = False
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackColor = Color.Transparent
        PictureBox1.Location = New Point(24, 63)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(94, 88)
        PictureBox1.SizeMode = PictureBoxSizeMode.CenterImage
        PictureBox1.TabIndex = 43
        PictureBox1.TabStop = False
        ' 
        ' PictureBox2
        ' 
        PictureBox2.BackColor = Color.Transparent
        PictureBox2.Location = New Point(24, 157)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(94, 88)
        PictureBox2.SizeMode = PictureBoxSizeMode.CenterImage
        PictureBox2.TabIndex = 44
        PictureBox2.TabStop = False
        ' 
        ' PictureBox3
        ' 
        PictureBox3.BackColor = Color.Transparent
        PictureBox3.Location = New Point(24, 251)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(94, 88)
        PictureBox3.SizeMode = PictureBoxSizeMode.CenterImage
        PictureBox3.TabIndex = 45
        PictureBox3.TabStop = False
        ' 
        ' btnAddPink
        ' 
        btnAddPink.BackColor = Color.Transparent
        btnAddPink.Image = CType(resources.GetObject("btnAddPink.Image"), Image)
        btnAddPink.Location = New Point(243, 80)
        btnAddPink.Name = "btnAddPink"
        btnAddPink.Size = New Size(42, 50)
        btnAddPink.SizeMode = PictureBoxSizeMode.CenterImage
        btnAddPink.TabIndex = 46
        btnAddPink.TabStop = False
        ' 
        ' btnMinusPink
        ' 
        btnMinusPink.BackColor = Color.Transparent
        btnMinusPink.Image = CType(resources.GetObject("btnMinusPink.Image"), Image)
        btnMinusPink.Location = New Point(316, 80)
        btnMinusPink.Name = "btnMinusPink"
        btnMinusPink.Size = New Size(42, 50)
        btnMinusPink.SizeMode = PictureBoxSizeMode.CenterImage
        btnMinusPink.TabIndex = 52
        btnMinusPink.TabStop = False
        ' 
        ' btnAddWhite
        ' 
        btnAddWhite.BackColor = Color.Transparent
        btnAddWhite.Image = CType(resources.GetObject("btnAddWhite.Image"), Image)
        btnAddWhite.Location = New Point(243, 266)
        btnAddWhite.Name = "btnAddWhite"
        btnAddWhite.Size = New Size(42, 50)
        btnAddWhite.SizeMode = PictureBoxSizeMode.CenterImage
        btnAddWhite.TabIndex = 55
        btnAddWhite.TabStop = False
        ' 
        ' btnAddBlue
        ' 
        btnAddBlue.BackColor = Color.Transparent
        btnAddBlue.Image = CType(resources.GetObject("btnAddBlue.Image"), Image)
        btnAddBlue.Location = New Point(243, 175)
        btnAddBlue.Name = "btnAddBlue"
        btnAddBlue.Size = New Size(42, 50)
        btnAddBlue.SizeMode = PictureBoxSizeMode.CenterImage
        btnAddBlue.TabIndex = 56
        btnAddBlue.TabStop = False
        ' 
        ' btnMinusWhite
        ' 
        btnMinusWhite.BackColor = Color.Transparent
        btnMinusWhite.Image = CType(resources.GetObject("btnMinusWhite.Image"), Image)
        btnMinusWhite.Location = New Point(316, 266)
        btnMinusWhite.Name = "btnMinusWhite"
        btnMinusWhite.Size = New Size(42, 50)
        btnMinusWhite.SizeMode = PictureBoxSizeMode.CenterImage
        btnMinusWhite.TabIndex = 57
        btnMinusWhite.TabStop = False
        ' 
        ' btnMinusBlue
        ' 
        btnMinusBlue.BackColor = Color.Transparent
        btnMinusBlue.Image = CType(resources.GetObject("btnMinusBlue.Image"), Image)
        btnMinusBlue.Location = New Point(316, 175)
        btnMinusBlue.Name = "btnMinusBlue"
        btnMinusBlue.Size = New Size(42, 50)
        btnMinusBlue.SizeMode = PictureBoxSizeMode.CenterImage
        btnMinusBlue.TabIndex = 58
        btnMinusBlue.TabStop = False
        ' 
        ' lblPink
        ' 
        lblPink.AutoSize = True
        lblPink.BackColor = Color.Transparent
        lblPink.Font = New Font("Rockwell", 14.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        lblPink.Location = New Point(291, 95)
        lblPink.Name = "lblPink"
        lblPink.Size = New Size(20, 21)
        lblPink.TabIndex = 59
        lblPink.Text = "1"
        ' 
        ' lblBlue
        ' 
        lblBlue.AutoSize = True
        lblBlue.BackColor = Color.Transparent
        lblBlue.Font = New Font("Rockwell", 14.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        lblBlue.Location = New Point(290, 190)
        lblBlue.Name = "lblBlue"
        lblBlue.Size = New Size(20, 21)
        lblBlue.TabIndex = 60
        lblBlue.Text = "1"
        ' 
        ' lblWhite
        ' 
        lblWhite.AutoSize = True
        lblWhite.BackColor = Color.Transparent
        lblWhite.Font = New Font("Rockwell", 14.25F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        lblWhite.Location = New Point(291, 282)
        lblWhite.Name = "lblWhite"
        lblWhite.Size = New Size(20, 21)
        lblWhite.TabIndex = 61
        lblWhite.Text = "1"
        ' 
        ' lblItemName1
        ' 
        lblItemName1.AutoSize = True
        lblItemName1.BackColor = Color.Transparent
        lblItemName1.Font = New Font("STHupo", 9.75F)
        lblItemName1.Location = New Point(140, 80)
        lblItemName1.Name = "lblItemName1"
        lblItemName1.Size = New Size(0, 13)
        lblItemName1.TabIndex = 62
        ' 
        ' lblRM1
        ' 
        lblRM1.AutoSize = True
        lblRM1.BackColor = Color.Transparent
        lblRM1.Font = New Font("STHupo", 9.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(134))
        lblRM1.Location = New Point(140, 115)
        lblRM1.Name = "lblRM1"
        lblRM1.Size = New Size(26, 13)
        lblRM1.TabIndex = 63
        lblRM1.Text = "RM"
        ' 
        ' lblPrice1
        ' 
        lblPrice1.AutoSize = True
        lblPrice1.BackColor = Color.Transparent
        lblPrice1.Font = New Font("STHupo", 9.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(134))
        lblPrice1.Location = New Point(172, 113)
        lblPrice1.Name = "lblPrice1"
        lblPrice1.Size = New Size(0, 13)
        lblPrice1.TabIndex = 64
        ' 
        ' lblItemName2
        ' 
        lblItemName2.AutoSize = True
        lblItemName2.BackColor = Color.Transparent
        lblItemName2.Font = New Font("STHupo", 9.75F)
        lblItemName2.Location = New Point(140, 175)
        lblItemName2.Name = "lblItemName2"
        lblItemName2.Size = New Size(0, 13)
        lblItemName2.TabIndex = 65
        ' 
        ' lblRM2
        ' 
        lblRM2.AutoSize = True
        lblRM2.BackColor = Color.Transparent
        lblRM2.Font = New Font("STHupo", 9.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(134))
        lblRM2.Location = New Point(140, 210)
        lblRM2.Name = "lblRM2"
        lblRM2.Size = New Size(26, 13)
        lblRM2.TabIndex = 66
        lblRM2.Text = "RM"
        ' 
        ' lblPrice2
        ' 
        lblPrice2.AutoSize = True
        lblPrice2.BackColor = Color.Transparent
        lblPrice2.Font = New Font("STHupo", 9.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(134))
        lblPrice2.Location = New Point(172, 208)
        lblPrice2.Name = "lblPrice2"
        lblPrice2.Size = New Size(0, 13)
        lblPrice2.TabIndex = 67
        ' 
        ' lblRM3
        ' 
        lblRM3.AutoSize = True
        lblRM3.BackColor = Color.Transparent
        lblRM3.Font = New Font("STHupo", 9.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(134))
        lblRM3.Location = New Point(140, 301)
        lblRM3.Name = "lblRM3"
        lblRM3.Size = New Size(26, 13)
        lblRM3.TabIndex = 68
        lblRM3.Text = "RM"
        ' 
        ' lblItemName3
        ' 
        lblItemName3.AutoSize = True
        lblItemName3.BackColor = Color.Transparent
        lblItemName3.Font = New Font("STHupo", 9.75F)
        lblItemName3.Location = New Point(140, 266)
        lblItemName3.Name = "lblItemName3"
        lblItemName3.Size = New Size(0, 13)
        lblItemName3.TabIndex = 69
        ' 
        ' lblPrice3
        ' 
        lblPrice3.AutoSize = True
        lblPrice3.BackColor = Color.Transparent
        lblPrice3.Font = New Font("STHupo", 9.75F)
        lblPrice3.Location = New Point(172, 299)
        lblPrice3.Name = "lblPrice3"
        lblPrice3.Size = New Size(0, 13)
        lblPrice3.TabIndex = 70
        ' 
        ' Cart
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(370, 700)
        Controls.Add(lblPrice3)
        Controls.Add(lblItemName3)
        Controls.Add(lblRM3)
        Controls.Add(lblPrice2)
        Controls.Add(lblRM2)
        Controls.Add(lblItemName2)
        Controls.Add(lblPrice1)
        Controls.Add(lblRM1)
        Controls.Add(lblItemName1)
        Controls.Add(lblWhite)
        Controls.Add(lblBlue)
        Controls.Add(lblPink)
        Controls.Add(btnMinusBlue)
        Controls.Add(btnMinusWhite)
        Controls.Add(btnAddBlue)
        Controls.Add(btnAddWhite)
        Controls.Add(btnMinusPink)
        Controls.Add(btnAddPink)
        Controls.Add(PictureBox3)
        Controls.Add(PictureBox2)
        Controls.Add(PictureBox1)
        Controls.Add(btnCheckout)
        Controls.Add(lblTotal)
        Controls.Add(Label8)
        Controls.Add(Label5)
        Controls.Add(Label3)
        Controls.Add(Label7)
        Controls.Add(Label6)
        Controls.Add(lblDeliveryFee)
        Controls.Add(Label4)
        Controls.Add(lblSubTotal)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(btnProfile3)
        Controls.Add(btnNotification3)
        Controls.Add(btnSearch3)
        Controls.Add(btnCategory3)
        Controls.Add(btnHome3)
        FormBorderStyle = FormBorderStyle.None
        Name = "Cart"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Purchase"
        CType(btnProfile3, ComponentModel.ISupportInitialize).EndInit()
        CType(btnNotification3, ComponentModel.ISupportInitialize).EndInit()
        CType(btnSearch3, ComponentModel.ISupportInitialize).EndInit()
        CType(btnCategory3, ComponentModel.ISupportInitialize).EndInit()
        CType(btnHome3, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        CType(btnAddPink, ComponentModel.ISupportInitialize).EndInit()
        CType(btnMinusPink, ComponentModel.ISupportInitialize).EndInit()
        CType(btnAddWhite, ComponentModel.ISupportInitialize).EndInit()
        CType(btnAddBlue, ComponentModel.ISupportInitialize).EndInit()
        CType(btnMinusWhite, ComponentModel.ISupportInitialize).EndInit()
        CType(btnMinusBlue, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents btnProfile3 As PictureBox
    Friend WithEvents btnNotification3 As PictureBox
    Friend WithEvents btnSearch3 As PictureBox
    Friend WithEvents btnCategory3 As PictureBox
    Friend WithEvents btnHome3 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents lblSubTotal As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents lblDeliveryFee As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents lblTotal As Label
    Friend WithEvents btnCheckout As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents btnAddPink As PictureBox
    Friend WithEvents btnMinusPink As PictureBox
    Friend WithEvents btnAddWhite As PictureBox
    Friend WithEvents btnAddBlue As PictureBox
    Friend WithEvents btnMinusWhite As PictureBox
    Friend WithEvents btnMinusBlue As PictureBox
    Friend WithEvents lblPink As Label
    Friend WithEvents lblBlue As Label
    Friend WithEvents lblWhite As Label
    Friend WithEvents lblItemName1 As Label
    Friend WithEvents lblRM1 As Label
    Friend WithEvents lblPrice1 As Label
    Friend WithEvents lblItemName2 As Label
    Friend WithEvents lblRM2 As Label
    Friend WithEvents lblPrice2 As Label
    Friend WithEvents lblRM3 As Label
    Friend WithEvents lblItemName3 As Label
    Friend WithEvents lblPrice3 As Label
End Class
