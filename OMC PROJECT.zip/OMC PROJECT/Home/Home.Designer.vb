﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Home
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Home))
        btnSettings = New PictureBox()
        btnBeASeller = New PictureBox()
        btnCommunication = New PictureBox()
        btnChallenges = New PictureBox()
        btnPaymentHistory = New PictureBox()
        btnPurchase = New PictureBox()
        btnBack = New PictureBox()
        PictureBox1 = New PictureBox()
        btnHome1 = New PictureBox()
        btnProfile1 = New PictureBox()
        btnNotification1 = New PictureBox()
        btnSearch1 = New PictureBox()
        btnCategory1 = New PictureBox()
        PictureBox2 = New PictureBox()
        CType(btnSettings, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnBeASeller, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnCommunication, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnChallenges, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnPaymentHistory, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnPurchase, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnBack, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnHome1, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnProfile1, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnNotification1, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnSearch1, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnCategory1, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' btnSettings
        ' 
        btnSettings.BackColor = Color.Transparent
        btnSettings.Image = CType(resources.GetObject("btnSettings.Image"), Image)
        btnSettings.Location = New Point(48, 89)
        btnSettings.Name = "btnSettings"
        btnSettings.Size = New Size(118, 139)
        btnSettings.SizeMode = PictureBoxSizeMode.CenterImage
        btnSettings.TabIndex = 0
        btnSettings.TabStop = False
        btnSettings.UseWaitCursor = True
        ' 
        ' btnBeASeller
        ' 
        btnBeASeller.BackColor = Color.Transparent
        btnBeASeller.Image = CType(resources.GetObject("btnBeASeller.Image"), Image)
        btnBeASeller.Location = New Point(48, 253)
        btnBeASeller.Name = "btnBeASeller"
        btnBeASeller.Size = New Size(118, 142)
        btnBeASeller.SizeMode = PictureBoxSizeMode.CenterImage
        btnBeASeller.TabIndex = 1
        btnBeASeller.TabStop = False
        ' 
        ' btnCommunication
        ' 
        btnCommunication.BackColor = Color.Transparent
        btnCommunication.Image = CType(resources.GetObject("btnCommunication.Image"), Image)
        btnCommunication.Location = New Point(196, 253)
        btnCommunication.Name = "btnCommunication"
        btnCommunication.Size = New Size(118, 142)
        btnCommunication.SizeMode = PictureBoxSizeMode.CenterImage
        btnCommunication.TabIndex = 2
        btnCommunication.TabStop = False
        ' 
        ' btnChallenges
        ' 
        btnChallenges.BackColor = Color.Transparent
        btnChallenges.Image = CType(resources.GetObject("btnChallenges.Image"), Image)
        btnChallenges.Location = New Point(48, 422)
        btnChallenges.Name = "btnChallenges"
        btnChallenges.Size = New Size(118, 135)
        btnChallenges.SizeMode = PictureBoxSizeMode.CenterImage
        btnChallenges.TabIndex = 3
        btnChallenges.TabStop = False
        ' 
        ' btnPaymentHistory
        ' 
        btnPaymentHistory.BackColor = Color.Transparent
        btnPaymentHistory.Image = CType(resources.GetObject("btnPaymentHistory.Image"), Image)
        btnPaymentHistory.Location = New Point(196, 89)
        btnPaymentHistory.Name = "btnPaymentHistory"
        btnPaymentHistory.Size = New Size(118, 139)
        btnPaymentHistory.SizeMode = PictureBoxSizeMode.CenterImage
        btnPaymentHistory.TabIndex = 4
        btnPaymentHistory.TabStop = False
        ' 
        ' btnPurchase
        ' 
        btnPurchase.BackColor = Color.Transparent
        btnPurchase.Image = CType(resources.GetObject("btnPurchase.Image"), Image)
        btnPurchase.Location = New Point(196, 422)
        btnPurchase.Name = "btnPurchase"
        btnPurchase.Size = New Size(118, 135)
        btnPurchase.SizeMode = PictureBoxSizeMode.CenterImage
        btnPurchase.TabIndex = 5
        btnPurchase.TabStop = False
        ' 
        ' btnBack
        ' 
        btnBack.BackColor = Color.Transparent
        btnBack.Image = CType(resources.GetObject("btnBack.Image"), Image)
        btnBack.Location = New Point(32, 12)
        btnBack.Name = "btnBack"
        btnBack.Size = New Size(43, 49)
        btnBack.SizeMode = PictureBoxSizeMode.Zoom
        btnBack.TabIndex = 9
        btnBack.TabStop = False
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackColor = Color.Transparent
        PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), Image)
        PictureBox1.Location = New Point(286, 12)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(50, 52)
        PictureBox1.SizeMode = PictureBoxSizeMode.StretchImage
        PictureBox1.TabIndex = 10
        PictureBox1.TabStop = False
        ' 
        ' btnHome1
        ' 
        btnHome1.BackColor = Color.Transparent
        btnHome1.Image = CType(resources.GetObject("btnHome1.Image"), Image)
        btnHome1.Location = New Point(32, 591)
        btnHome1.Name = "btnHome1"
        btnHome1.Size = New Size(56, 58)
        btnHome1.SizeMode = PictureBoxSizeMode.Zoom
        btnHome1.TabIndex = 11
        btnHome1.TabStop = False
        ' 
        ' btnProfile1
        ' 
        btnProfile1.BackColor = Color.Transparent
        btnProfile1.Cursor = Cursors.Hand
        btnProfile1.Image = CType(resources.GetObject("btnProfile1.Image"), Image)
        btnProfile1.Location = New Point(280, 591)
        btnProfile1.Name = "btnProfile1"
        btnProfile1.Size = New Size(56, 58)
        btnProfile1.SizeMode = PictureBoxSizeMode.Zoom
        btnProfile1.TabIndex = 12
        btnProfile1.TabStop = False
        ' 
        ' btnNotification1
        ' 
        btnNotification1.BackColor = Color.Transparent
        btnNotification1.Cursor = Cursors.Hand
        btnNotification1.Image = CType(resources.GetObject("btnNotification1.Image"), Image)
        btnNotification1.Location = New Point(218, 591)
        btnNotification1.Name = "btnNotification1"
        btnNotification1.Size = New Size(56, 58)
        btnNotification1.SizeMode = PictureBoxSizeMode.Zoom
        btnNotification1.TabIndex = 13
        btnNotification1.TabStop = False
        ' 
        ' btnSearch1
        ' 
        btnSearch1.BackColor = Color.Transparent
        btnSearch1.Cursor = Cursors.Hand
        btnSearch1.Image = CType(resources.GetObject("btnSearch1.Image"), Image)
        btnSearch1.Location = New Point(156, 591)
        btnSearch1.Name = "btnSearch1"
        btnSearch1.Size = New Size(56, 58)
        btnSearch1.SizeMode = PictureBoxSizeMode.Zoom
        btnSearch1.TabIndex = 14
        btnSearch1.TabStop = False
        ' 
        ' btnCategory1
        ' 
        btnCategory1.BackColor = Color.Transparent
        btnCategory1.Cursor = Cursors.Hand
        btnCategory1.Image = CType(resources.GetObject("btnCategory1.Image"), Image)
        btnCategory1.Location = New Point(94, 591)
        btnCategory1.Name = "btnCategory1"
        btnCategory1.Size = New Size(56, 58)
        btnCategory1.SizeMode = PictureBoxSizeMode.Zoom
        btnCategory1.TabIndex = 15
        btnCategory1.TabStop = False
        ' 
        ' PictureBox2
        ' 
        PictureBox2.BackColor = Color.Transparent
        PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), Image)
        PictureBox2.Location = New Point(342, -1)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(28, 26)
        PictureBox2.SizeMode = PictureBoxSizeMode.CenterImage
        PictureBox2.TabIndex = 16
        PictureBox2.TabStop = False
        ' 
        ' Home
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        BackColor = SystemColors.Control
        ClientSize = New Size(370, 700)
        Controls.Add(PictureBox2)
        Controls.Add(btnCategory1)
        Controls.Add(btnSearch1)
        Controls.Add(btnNotification1)
        Controls.Add(btnProfile1)
        Controls.Add(btnHome1)
        Controls.Add(PictureBox1)
        Controls.Add(btnBack)
        Controls.Add(btnPurchase)
        Controls.Add(btnPaymentHistory)
        Controls.Add(btnChallenges)
        Controls.Add(btnCommunication)
        Controls.Add(btnBeASeller)
        Controls.Add(btnSettings)
        FormBorderStyle = FormBorderStyle.None
        Name = "Home"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Home"
        CType(btnSettings, ComponentModel.ISupportInitialize).EndInit()
        CType(btnBeASeller, ComponentModel.ISupportInitialize).EndInit()
        CType(btnCommunication, ComponentModel.ISupportInitialize).EndInit()
        CType(btnChallenges, ComponentModel.ISupportInitialize).EndInit()
        CType(btnPaymentHistory, ComponentModel.ISupportInitialize).EndInit()
        CType(btnPurchase, ComponentModel.ISupportInitialize).EndInit()
        CType(btnBack, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(btnHome1, ComponentModel.ISupportInitialize).EndInit()
        CType(btnProfile1, ComponentModel.ISupportInitialize).EndInit()
        CType(btnNotification1, ComponentModel.ISupportInitialize).EndInit()
        CType(btnSearch1, ComponentModel.ISupportInitialize).EndInit()
        CType(btnCategory1, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
    End Sub

    Friend WithEvents btnSettings As PictureBox
    Friend WithEvents btnBeASeller As PictureBox
    Friend WithEvents btnCommunication As PictureBox
    Friend WithEvents btnChallenges As PictureBox
    Friend WithEvents btnPaymentHistory As PictureBox
    Friend WithEvents btnPurchase As PictureBox
    Friend WithEvents btnBack As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnHome1 As PictureBox
    Friend WithEvents btnProfile1 As PictureBox
    Friend WithEvents btnNotification1 As PictureBox
    Friend WithEvents btnSearch1 As PictureBox
    Friend WithEvents btnCategory1 As PictureBox
    Friend WithEvents PictureBox2 As PictureBox
End Class
