﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Category
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Category))
        btnProfile3 = New PictureBox()
        btnNotification3 = New PictureBox()
        btnSearch3 = New PictureBox()
        btnCategory3 = New PictureBox()
        btnHome3 = New PictureBox()
        btnBack = New PictureBox()
        PictureBox1 = New PictureBox()
        btnTravelling = New PictureBox()
        btnPets = New PictureBox()
        btnSports = New PictureBox()
        btnClothes = New PictureBox()
        btnKitchen = New PictureBox()
        Label1 = New Label()
        Label2 = New Label()
        Label3 = New Label()
        Label4 = New Label()
        Label5 = New Label()
        Label6 = New Label()
        PictureBox2 = New PictureBox()
        CType(btnProfile3, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnNotification3, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnSearch3, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnCategory3, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnHome3, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnBack, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnTravelling, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnPets, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnSports, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnClothes, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnKitchen, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' btnProfile3
        ' 
        btnProfile3.BackColor = Color.Transparent
        btnProfile3.Image = CType(resources.GetObject("btnProfile3.Image"), Image)
        btnProfile3.Location = New Point(280, 591)
        btnProfile3.Name = "btnProfile3"
        btnProfile3.Size = New Size(56, 58)
        btnProfile3.SizeMode = PictureBoxSizeMode.Zoom
        btnProfile3.TabIndex = 22
        btnProfile3.TabStop = False
        ' 
        ' btnNotification3
        ' 
        btnNotification3.BackColor = Color.Transparent
        btnNotification3.Image = CType(resources.GetObject("btnNotification3.Image"), Image)
        btnNotification3.Location = New Point(218, 591)
        btnNotification3.Name = "btnNotification3"
        btnNotification3.Size = New Size(56, 58)
        btnNotification3.SizeMode = PictureBoxSizeMode.Zoom
        btnNotification3.TabIndex = 23
        btnNotification3.TabStop = False
        ' 
        ' btnSearch3
        ' 
        btnSearch3.BackColor = Color.Transparent
        btnSearch3.Image = CType(resources.GetObject("btnSearch3.Image"), Image)
        btnSearch3.Location = New Point(156, 591)
        btnSearch3.Name = "btnSearch3"
        btnSearch3.Size = New Size(56, 58)
        btnSearch3.SizeMode = PictureBoxSizeMode.Zoom
        btnSearch3.TabIndex = 24
        btnSearch3.TabStop = False
        ' 
        ' btnCategory3
        ' 
        btnCategory3.BackColor = Color.Transparent
        btnCategory3.Image = CType(resources.GetObject("btnCategory3.Image"), Image)
        btnCategory3.Location = New Point(94, 591)
        btnCategory3.Name = "btnCategory3"
        btnCategory3.Size = New Size(56, 58)
        btnCategory3.SizeMode = PictureBoxSizeMode.Zoom
        btnCategory3.TabIndex = 25
        btnCategory3.TabStop = False
        ' 
        ' btnHome3
        ' 
        btnHome3.BackColor = Color.Transparent
        btnHome3.Image = CType(resources.GetObject("btnHome3.Image"), Image)
        btnHome3.Location = New Point(32, 591)
        btnHome3.Name = "btnHome3"
        btnHome3.Size = New Size(56, 58)
        btnHome3.SizeMode = PictureBoxSizeMode.Zoom
        btnHome3.TabIndex = 21
        btnHome3.TabStop = False
        ' 
        ' btnBack
        ' 
        btnBack.BackColor = Color.Transparent
        btnBack.Image = CType(resources.GetObject("btnBack.Image"), Image)
        btnBack.Location = New Point(13, 15)
        btnBack.Name = "btnBack"
        btnBack.Size = New Size(43, 49)
        btnBack.SizeMode = PictureBoxSizeMode.Zoom
        btnBack.TabIndex = 26
        btnBack.TabStop = False
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackColor = Color.Transparent
        PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), Image)
        PictureBox1.Location = New Point(286, 12)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(50, 52)
        PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox1.TabIndex = 27
        PictureBox1.TabStop = False
        ' 
        ' btnTravelling
        ' 
        btnTravelling.Anchor = AnchorStyles.Top Or AnchorStyles.Bottom Or AnchorStyles.Left Or AnchorStyles.Right
        btnTravelling.BackColor = Color.Transparent
        btnTravelling.BackgroundImageLayout = ImageLayout.Center
        btnTravelling.Image = CType(resources.GetObject("btnTravelling.Image"), Image)
        btnTravelling.Location = New Point(12, 468)
        btnTravelling.Name = "btnTravelling"
        btnTravelling.Size = New Size(342, 89)
        btnTravelling.SizeMode = PictureBoxSizeMode.CenterImage
        btnTravelling.TabIndex = 28
        btnTravelling.TabStop = False
        ' 
        ' btnPets
        ' 
        btnPets.BackColor = Color.Transparent
        btnPets.Image = CType(resources.GetObject("btnPets.Image"), Image)
        btnPets.Location = New Point(12, 373)
        btnPets.Name = "btnPets"
        btnPets.Size = New Size(342, 89)
        btnPets.SizeMode = PictureBoxSizeMode.CenterImage
        btnPets.TabIndex = 29
        btnPets.TabStop = False
        ' 
        ' btnSports
        ' 
        btnSports.BackColor = Color.Transparent
        btnSports.Image = CType(resources.GetObject("btnSports.Image"), Image)
        btnSports.Location = New Point(12, 278)
        btnSports.Name = "btnSports"
        btnSports.Size = New Size(342, 89)
        btnSports.SizeMode = PictureBoxSizeMode.CenterImage
        btnSports.TabIndex = 30
        btnSports.TabStop = False
        ' 
        ' btnClothes
        ' 
        btnClothes.BackColor = Color.Transparent
        btnClothes.Image = CType(resources.GetObject("btnClothes.Image"), Image)
        btnClothes.Location = New Point(12, 183)
        btnClothes.Name = "btnClothes"
        btnClothes.Size = New Size(342, 89)
        btnClothes.SizeMode = PictureBoxSizeMode.CenterImage
        btnClothes.TabIndex = 31
        btnClothes.TabStop = False
        ' 
        ' btnKitchen
        ' 
        btnKitchen.BackColor = Color.Transparent
        btnKitchen.Image = CType(resources.GetObject("btnKitchen.Image"), Image)
        btnKitchen.Location = New Point(12, 88)
        btnKitchen.Name = "btnKitchen"
        btnKitchen.Size = New Size(342, 89)
        btnKitchen.SizeMode = PictureBoxSizeMode.CenterImage
        btnKitchen.TabIndex = 32
        btnKitchen.TabStop = False
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.Transparent
        Label1.Font = New Font("STHupo", 20.2499981F, FontStyle.Regular, GraphicsUnit.Point, CByte(134))
        Label1.Location = New Point(107, 23)
        Label1.Name = "Label1"
        Label1.Size = New Size(145, 28)
        Label1.TabIndex = 33
        Label1.Text = "Categories"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.BackColor = Color.Transparent
        Label2.Font = New Font("STXihei", 9.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label2.Location = New Point(205, 479)
        Label2.Name = "Label2"
        Label2.Size = New Size(131, 14)
        Label2.TabIndex = 34
        Label2.Text = "Outdoor And Travel"
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.BackColor = Color.Transparent
        Label3.Font = New Font("STXihei", 9.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(134))
        Label3.Location = New Point(234, 192)
        Label3.Name = "Label3"
        Label3.Size = New Size(102, 28)
        Label3.TabIndex = 35
        Label3.Text = "Clothes " & vbCrLf & "And Acessories"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.BackColor = Color.Transparent
        Label4.Font = New Font("STXihei", 9.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(134))
        Label4.Location = New Point(24, 99)
        Label4.Name = "Label4"
        Label4.Size = New Size(112, 14)
        Label4.TabIndex = 36
        Label4.Text = "Kitchen Products" & vbCrLf
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.BackColor = Color.Transparent
        Label5.Font = New Font("STXihei", 9.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label5.Location = New Point(278, 301)
        Label5.Name = "Label5"
        Label5.Size = New Size(44, 14)
        Label5.TabIndex = 37
        Label5.Text = "Sports"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.BackColor = Color.Transparent
        Label6.Font = New Font("STXihei", 9.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(0))
        Label6.Location = New Point(24, 386)
        Label6.Name = "Label6"
        Label6.Size = New Size(32, 14)
        Label6.TabIndex = 38
        Label6.Text = "Pets"
        ' 
        ' PictureBox2
        ' 
        PictureBox2.BackColor = Color.Transparent
        PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), Image)
        PictureBox2.Location = New Point(342, -1)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(28, 26)
        PictureBox2.SizeMode = PictureBoxSizeMode.CenterImage
        PictureBox2.TabIndex = 39
        PictureBox2.TabStop = False
        ' 
        ' Category
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(370, 700)
        Controls.Add(PictureBox2)
        Controls.Add(Label6)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(btnKitchen)
        Controls.Add(btnClothes)
        Controls.Add(btnSports)
        Controls.Add(btnPets)
        Controls.Add(btnTravelling)
        Controls.Add(PictureBox1)
        Controls.Add(btnBack)
        Controls.Add(btnProfile3)
        Controls.Add(btnNotification3)
        Controls.Add(btnSearch3)
        Controls.Add(btnCategory3)
        Controls.Add(btnHome3)
        FormBorderStyle = FormBorderStyle.None
        Name = "Category"
        SizeGripStyle = SizeGripStyle.Show
        StartPosition = FormStartPosition.CenterScreen
        Text = "Category"
        CType(btnProfile3, ComponentModel.ISupportInitialize).EndInit()
        CType(btnNotification3, ComponentModel.ISupportInitialize).EndInit()
        CType(btnSearch3, ComponentModel.ISupportInitialize).EndInit()
        CType(btnCategory3, ComponentModel.ISupportInitialize).EndInit()
        CType(btnHome3, ComponentModel.ISupportInitialize).EndInit()
        CType(btnBack, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(btnTravelling, ComponentModel.ISupportInitialize).EndInit()
        CType(btnPets, ComponentModel.ISupportInitialize).EndInit()
        CType(btnSports, ComponentModel.ISupportInitialize).EndInit()
        CType(btnClothes, ComponentModel.ISupportInitialize).EndInit()
        CType(btnKitchen, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents btnProfile3 As PictureBox
    Friend WithEvents btnNotification3 As PictureBox
    Friend WithEvents btnSearch3 As PictureBox
    Friend WithEvents btnCategory3 As PictureBox
    Friend WithEvents btnHome3 As PictureBox
    Friend WithEvents btnBack As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnTravelling As PictureBox
    Friend WithEvents btnPets As PictureBox
    Friend WithEvents btnSports As PictureBox
    Friend WithEvents btnClothes As PictureBox
    Friend WithEvents btnKitchen As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents PictureBox2 As PictureBox
End Class
