﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Search
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Search))
        btnCategory2 = New PictureBox()
        btnSearch2 = New PictureBox()
        btnNotification2 = New PictureBox()
        btnProfile2 = New PictureBox()
        btnHome2 = New PictureBox()
        btnBack = New PictureBox()
        PictureBox1 = New PictureBox()
        btnSearchBar = New PictureBox()
        txtSearchBar = New TextBox()
        PictureBox6 = New PictureBox()
        Item1 = New PictureBox()
        Item4 = New PictureBox()
        Item3 = New PictureBox()
        Item2 = New PictureBox()
        lblItemName1 = New Label()
        lblPrice1 = New Label()
        lblItemName2 = New Label()
        lblPrice2 = New Label()
        lblItemName3 = New Label()
        lblPrice3 = New Label()
        lblItemName4 = New Label()
        lblPrice4 = New Label()
        btnAdd1 = New Button()
        btnAdd2 = New Button()
        btnAdd3 = New Button()
        btnAdd4 = New Button()
        CType(btnCategory2, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnSearch2, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnNotification2, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnProfile2, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnHome2, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnBack, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnSearchBar, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox6, ComponentModel.ISupportInitialize).BeginInit()
        CType(Item1, ComponentModel.ISupportInitialize).BeginInit()
        CType(Item4, ComponentModel.ISupportInitialize).BeginInit()
        CType(Item3, ComponentModel.ISupportInitialize).BeginInit()
        CType(Item2, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' btnCategory2
        ' 
        btnCategory2.BackColor = Color.Transparent
        btnCategory2.Cursor = Cursors.Hand
        btnCategory2.Image = CType(resources.GetObject("btnCategory2.Image"), Image)
        btnCategory2.Location = New Point(94, 591)
        btnCategory2.Name = "btnCategory2"
        btnCategory2.Size = New Size(56, 58)
        btnCategory2.SizeMode = PictureBoxSizeMode.Zoom
        btnCategory2.TabIndex = 20
        btnCategory2.TabStop = False
        ' 
        ' btnSearch2
        ' 
        btnSearch2.BackColor = Color.Transparent
        btnSearch2.Image = CType(resources.GetObject("btnSearch2.Image"), Image)
        btnSearch2.Location = New Point(156, 591)
        btnSearch2.Name = "btnSearch2"
        btnSearch2.Size = New Size(56, 58)
        btnSearch2.SizeMode = PictureBoxSizeMode.Zoom
        btnSearch2.TabIndex = 19
        btnSearch2.TabStop = False
        ' 
        ' btnNotification2
        ' 
        btnNotification2.BackColor = Color.Transparent
        btnNotification2.Image = CType(resources.GetObject("btnNotification2.Image"), Image)
        btnNotification2.Location = New Point(218, 591)
        btnNotification2.Name = "btnNotification2"
        btnNotification2.Size = New Size(56, 58)
        btnNotification2.SizeMode = PictureBoxSizeMode.Zoom
        btnNotification2.TabIndex = 18
        btnNotification2.TabStop = False
        ' 
        ' btnProfile2
        ' 
        btnProfile2.BackColor = Color.Transparent
        btnProfile2.Image = CType(resources.GetObject("btnProfile2.Image"), Image)
        btnProfile2.Location = New Point(280, 591)
        btnProfile2.Name = "btnProfile2"
        btnProfile2.Size = New Size(56, 58)
        btnProfile2.SizeMode = PictureBoxSizeMode.Zoom
        btnProfile2.TabIndex = 17
        btnProfile2.TabStop = False
        ' 
        ' btnHome2
        ' 
        btnHome2.BackColor = Color.Transparent
        btnHome2.Cursor = Cursors.Hand
        btnHome2.Image = CType(resources.GetObject("btnHome2.Image"), Image)
        btnHome2.Location = New Point(32, 591)
        btnHome2.Name = "btnHome2"
        btnHome2.Size = New Size(56, 58)
        btnHome2.SizeMode = PictureBoxSizeMode.Zoom
        btnHome2.TabIndex = 16
        btnHome2.TabStop = False
        ' 
        ' btnBack
        ' 
        btnBack.BackColor = Color.Transparent
        btnBack.Image = CType(resources.GetObject("btnBack.Image"), Image)
        btnBack.Location = New Point(32, 12)
        btnBack.Name = "btnBack"
        btnBack.Size = New Size(43, 49)
        btnBack.SizeMode = PictureBoxSizeMode.Zoom
        btnBack.TabIndex = 8
        btnBack.TabStop = False
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackColor = Color.Transparent
        PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), Image)
        PictureBox1.Location = New Point(286, 12)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(50, 52)
        PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox1.TabIndex = 9
        PictureBox1.TabStop = False
        ' 
        ' btnSearchBar
        ' 
        btnSearchBar.BackColor = Color.Transparent
        btnSearchBar.Image = CType(resources.GetObject("btnSearchBar.Image"), Image)
        btnSearchBar.Location = New Point(262, 67)
        btnSearchBar.Name = "btnSearchBar"
        btnSearchBar.Size = New Size(37, 38)
        btnSearchBar.SizeMode = PictureBoxSizeMode.Zoom
        btnSearchBar.TabIndex = 22
        btnSearchBar.TabStop = False
        ' 
        ' txtSearchBar
        ' 
        txtSearchBar.Font = New Font("Rockwell", 12F, FontStyle.Bold)
        txtSearchBar.Location = New Point(61, 67)
        txtSearchBar.Multiline = True
        txtSearchBar.Name = "txtSearchBar"
        txtSearchBar.PlaceholderText = "Search"
        txtSearchBar.Size = New Size(195, 38)
        txtSearchBar.TabIndex = 23
        ' 
        ' PictureBox6
        ' 
        PictureBox6.BackColor = Color.Transparent
        PictureBox6.Image = CType(resources.GetObject("PictureBox6.Image"), Image)
        PictureBox6.Location = New Point(342, -1)
        PictureBox6.Name = "PictureBox6"
        PictureBox6.Size = New Size(28, 26)
        PictureBox6.SizeMode = PictureBoxSizeMode.CenterImage
        PictureBox6.TabIndex = 32
        PictureBox6.TabStop = False
        ' 
        ' Item1
        ' 
        Item1.BackColor = Color.Transparent
        Item1.Location = New Point(52, 125)
        Item1.Name = "Item1"
        Item1.Size = New Size(87, 102)
        Item1.SizeMode = PictureBoxSizeMode.CenterImage
        Item1.TabIndex = 33
        Item1.TabStop = False
        ' 
        ' Item4
        ' 
        Item4.BackColor = Color.Transparent
        Item4.Location = New Point(52, 449)
        Item4.Name = "Item4"
        Item4.Size = New Size(87, 102)
        Item4.SizeMode = PictureBoxSizeMode.CenterImage
        Item4.TabIndex = 34
        Item4.TabStop = False
        ' 
        ' Item3
        ' 
        Item3.BackColor = Color.Transparent
        Item3.Location = New Point(52, 341)
        Item3.Name = "Item3"
        Item3.Size = New Size(87, 102)
        Item3.SizeMode = PictureBoxSizeMode.CenterImage
        Item3.TabIndex = 35
        Item3.TabStop = False
        ' 
        ' Item2
        ' 
        Item2.BackColor = Color.Transparent
        Item2.Location = New Point(52, 233)
        Item2.Name = "Item2"
        Item2.Size = New Size(87, 102)
        Item2.SizeMode = PictureBoxSizeMode.CenterImage
        Item2.TabIndex = 36
        Item2.TabStop = False
        ' 
        ' lblItemName1
        ' 
        lblItemName1.AutoSize = True
        lblItemName1.BackColor = Color.Transparent
        lblItemName1.Font = New Font("STHupo", 9.75F)
        lblItemName1.Location = New Point(150, 149)
        lblItemName1.Name = "lblItemName1"
        lblItemName1.Size = New Size(0, 13)
        lblItemName1.TabIndex = 37
        ' 
        ' lblPrice1
        ' 
        lblPrice1.AutoSize = True
        lblPrice1.BackColor = Color.Transparent
        lblPrice1.Font = New Font("STHupo", 9.75F)
        lblPrice1.Location = New Point(150, 173)
        lblPrice1.Name = "lblPrice1"
        lblPrice1.Size = New Size(0, 13)
        lblPrice1.TabIndex = 39
        ' 
        ' lblItemName2
        ' 
        lblItemName2.AutoSize = True
        lblItemName2.BackColor = Color.Transparent
        lblItemName2.Font = New Font("STHupo", 9.75F)
        lblItemName2.Location = New Point(150, 253)
        lblItemName2.Name = "lblItemName2"
        lblItemName2.Size = New Size(0, 13)
        lblItemName2.TabIndex = 40
        ' 
        ' lblPrice2
        ' 
        lblPrice2.AutoSize = True
        lblPrice2.BackColor = Color.Transparent
        lblPrice2.Font = New Font("STHupo", 9.75F)
        lblPrice2.Location = New Point(150, 280)
        lblPrice2.Name = "lblPrice2"
        lblPrice2.Size = New Size(0, 13)
        lblPrice2.TabIndex = 42
        ' 
        ' lblItemName3
        ' 
        lblItemName3.AutoSize = True
        lblItemName3.BackColor = Color.Transparent
        lblItemName3.Font = New Font("STHupo", 9.75F)
        lblItemName3.Location = New Point(150, 357)
        lblItemName3.Name = "lblItemName3"
        lblItemName3.Size = New Size(0, 13)
        lblItemName3.TabIndex = 43
        ' 
        ' lblPrice3
        ' 
        lblPrice3.AutoSize = True
        lblPrice3.BackColor = Color.Transparent
        lblPrice3.Font = New Font("STHupo", 9.75F)
        lblPrice3.Location = New Point(150, 390)
        lblPrice3.Name = "lblPrice3"
        lblPrice3.Size = New Size(0, 13)
        lblPrice3.TabIndex = 45
        ' 
        ' lblItemName4
        ' 
        lblItemName4.AutoSize = True
        lblItemName4.BackColor = Color.Transparent
        lblItemName4.Font = New Font("STHupo", 9.75F)
        lblItemName4.Location = New Point(150, 469)
        lblItemName4.Name = "lblItemName4"
        lblItemName4.Size = New Size(0, 13)
        lblItemName4.TabIndex = 47
        ' 
        ' lblPrice4
        ' 
        lblPrice4.AutoSize = True
        lblPrice4.BackColor = Color.Transparent
        lblPrice4.Font = New Font("STHupo", 9.75F)
        lblPrice4.Location = New Point(150, 496)
        lblPrice4.Name = "lblPrice4"
        lblPrice4.Size = New Size(0, 13)
        lblPrice4.TabIndex = 49
        ' 
        ' btnAdd1
        ' 
        btnAdd1.BackColor = Color.Transparent
        btnAdd1.Location = New Point(224, 194)
        btnAdd1.Name = "btnAdd1"
        btnAdd1.Size = New Size(86, 23)
        btnAdd1.TabIndex = 50
        btnAdd1.Text = "Add To Cart"
        btnAdd1.UseVisualStyleBackColor = False
        ' 
        ' btnAdd2
        ' 
        btnAdd2.BackColor = Color.Transparent
        btnAdd2.Location = New Point(224, 302)
        btnAdd2.Name = "btnAdd2"
        btnAdd2.Size = New Size(86, 23)
        btnAdd2.TabIndex = 51
        btnAdd2.Text = "Add To Cart"
        btnAdd2.UseVisualStyleBackColor = False
        ' 
        ' btnAdd3
        ' 
        btnAdd3.BackColor = Color.Transparent
        btnAdd3.Location = New Point(224, 410)
        btnAdd3.Name = "btnAdd3"
        btnAdd3.Size = New Size(86, 23)
        btnAdd3.TabIndex = 52
        btnAdd3.Text = "Add To Cart"
        btnAdd3.UseVisualStyleBackColor = False
        ' 
        ' btnAdd4
        ' 
        btnAdd4.BackColor = Color.Transparent
        btnAdd4.Location = New Point(224, 518)
        btnAdd4.Name = "btnAdd4"
        btnAdd4.Size = New Size(86, 24)
        btnAdd4.TabIndex = 53
        btnAdd4.Text = "Add To Cart"
        btnAdd4.UseVisualStyleBackColor = False
        ' 
        ' Search
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(370, 700)
        Controls.Add(btnAdd4)
        Controls.Add(btnAdd3)
        Controls.Add(btnAdd2)
        Controls.Add(btnAdd1)
        Controls.Add(lblPrice4)
        Controls.Add(lblItemName4)
        Controls.Add(lblPrice3)
        Controls.Add(lblItemName3)
        Controls.Add(lblPrice2)
        Controls.Add(lblItemName2)
        Controls.Add(lblPrice1)
        Controls.Add(lblItemName1)
        Controls.Add(Item2)
        Controls.Add(Item3)
        Controls.Add(Item4)
        Controls.Add(Item1)
        Controls.Add(PictureBox6)
        Controls.Add(txtSearchBar)
        Controls.Add(btnSearchBar)
        Controls.Add(PictureBox1)
        Controls.Add(btnProfile2)
        Controls.Add(btnBack)
        Controls.Add(btnNotification2)
        Controls.Add(btnSearch2)
        Controls.Add(btnCategory2)
        Controls.Add(btnHome2)
        FormBorderStyle = FormBorderStyle.None
        Name = "Search"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Home"
        CType(btnCategory2, ComponentModel.ISupportInitialize).EndInit()
        CType(btnSearch2, ComponentModel.ISupportInitialize).EndInit()
        CType(btnNotification2, ComponentModel.ISupportInitialize).EndInit()
        CType(btnProfile2, ComponentModel.ISupportInitialize).EndInit()
        CType(btnHome2, ComponentModel.ISupportInitialize).EndInit()
        CType(btnBack, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(btnSearchBar, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox6, ComponentModel.ISupportInitialize).EndInit()
        CType(Item1, ComponentModel.ISupportInitialize).EndInit()
        CType(Item4, ComponentModel.ISupportInitialize).EndInit()
        CType(Item3, ComponentModel.ISupportInitialize).EndInit()
        CType(Item2, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub
    Friend WithEvents btnCategory2 As PictureBox
    Friend WithEvents btnSearch2 As PictureBox
    Friend WithEvents btnNotification2 As PictureBox
    Friend WithEvents btnProfile2 As PictureBox
    Friend WithEvents btnHome2 As PictureBox
    Friend WithEvents btnBack As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnSearchBar As PictureBox
    Friend WithEvents txtSearchBar As TextBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents Item1 As PictureBox
    Friend WithEvents Item4 As PictureBox
    Friend WithEvents Item3 As PictureBox
    Friend WithEvents Item2 As PictureBox
    Friend WithEvents lblItemName1 As Label
    Friend WithEvents lblPrice1 As Label
    Friend WithEvents lblItemName2 As Label
    Friend WithEvents lblPrice2 As Label
    Friend WithEvents lblItemName3 As Label
    Friend WithEvents lblPrice3 As Label
    Friend WithEvents lblItemName4 As Label
    Friend WithEvents lblPrice4 As Label
    Friend WithEvents btnAdd1 As Button
    Friend WithEvents btnAdd2 As Button
    Friend WithEvents btnAdd3 As Button
    Friend WithEvents btnAdd4 As Button
End Class
