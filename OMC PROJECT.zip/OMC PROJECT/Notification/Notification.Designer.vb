﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Notification
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Notification))
        btnBack = New PictureBox()
        PictureBox1 = New PictureBox()
        btnCategory1 = New PictureBox()
        btnSearch1 = New PictureBox()
        btnNotification1 = New PictureBox()
        btnProfile1 = New PictureBox()
        btnHome1 = New PictureBox()
        Label1 = New Label()
        Label2 = New Label()
        PictureBox2 = New PictureBox()
        PictureBox3 = New PictureBox()
        PictureBox4 = New PictureBox()
        PictureBox5 = New PictureBox()
        PictureBox6 = New PictureBox()
        Label3 = New Label()
        Label4 = New Label()
        Label5 = New Label()
        Label6 = New Label()
        Label7 = New Label()
        Label8 = New Label()
        Label9 = New Label()
        Label10 = New Label()
        Label11 = New Label()
        PictureBox7 = New PictureBox()
        CType(btnBack, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnCategory1, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnSearch1, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnNotification1, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnProfile1, ComponentModel.ISupportInitialize).BeginInit()
        CType(btnHome1, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox6, ComponentModel.ISupportInitialize).BeginInit()
        CType(PictureBox7, ComponentModel.ISupportInitialize).BeginInit()
        SuspendLayout()
        ' 
        ' btnBack
        ' 
        btnBack.BackColor = Color.Transparent
        btnBack.Image = CType(resources.GetObject("btnBack.Image"), Image)
        btnBack.Location = New Point(24, 12)
        btnBack.Name = "btnBack"
        btnBack.Size = New Size(43, 49)
        btnBack.SizeMode = PictureBoxSizeMode.Zoom
        btnBack.TabIndex = 13
        btnBack.TabStop = False
        ' 
        ' PictureBox1
        ' 
        PictureBox1.BackColor = Color.Transparent
        PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), Image)
        PictureBox1.Location = New Point(286, 12)
        PictureBox1.Name = "PictureBox1"
        PictureBox1.Size = New Size(50, 52)
        PictureBox1.SizeMode = PictureBoxSizeMode.Zoom
        PictureBox1.TabIndex = 14
        PictureBox1.TabStop = False
        ' 
        ' btnCategory1
        ' 
        btnCategory1.BackColor = Color.Transparent
        btnCategory1.Cursor = Cursors.Hand
        btnCategory1.Image = CType(resources.GetObject("btnCategory1.Image"), Image)
        btnCategory1.Location = New Point(94, 591)
        btnCategory1.Name = "btnCategory1"
        btnCategory1.Size = New Size(56, 58)
        btnCategory1.SizeMode = PictureBoxSizeMode.Zoom
        btnCategory1.TabIndex = 20
        btnCategory1.TabStop = False
        ' 
        ' btnSearch1
        ' 
        btnSearch1.BackColor = Color.Transparent
        btnSearch1.Cursor = Cursors.Hand
        btnSearch1.Image = CType(resources.GetObject("btnSearch1.Image"), Image)
        btnSearch1.Location = New Point(156, 591)
        btnSearch1.Name = "btnSearch1"
        btnSearch1.Size = New Size(56, 58)
        btnSearch1.SizeMode = PictureBoxSizeMode.Zoom
        btnSearch1.TabIndex = 19
        btnSearch1.TabStop = False
        ' 
        ' btnNotification1
        ' 
        btnNotification1.BackColor = Color.Transparent
        btnNotification1.Cursor = Cursors.Hand
        btnNotification1.Image = CType(resources.GetObject("btnNotification1.Image"), Image)
        btnNotification1.Location = New Point(218, 591)
        btnNotification1.Name = "btnNotification1"
        btnNotification1.Size = New Size(56, 58)
        btnNotification1.SizeMode = PictureBoxSizeMode.Zoom
        btnNotification1.TabIndex = 18
        btnNotification1.TabStop = False
        ' 
        ' btnProfile1
        ' 
        btnProfile1.BackColor = Color.Transparent
        btnProfile1.Cursor = Cursors.Hand
        btnProfile1.Image = CType(resources.GetObject("btnProfile1.Image"), Image)
        btnProfile1.Location = New Point(280, 591)
        btnProfile1.Name = "btnProfile1"
        btnProfile1.Size = New Size(56, 58)
        btnProfile1.SizeMode = PictureBoxSizeMode.Zoom
        btnProfile1.TabIndex = 17
        btnProfile1.TabStop = False
        ' 
        ' btnHome1
        ' 
        btnHome1.BackColor = Color.Transparent
        btnHome1.Image = CType(resources.GetObject("btnHome1.Image"), Image)
        btnHome1.Location = New Point(32, 591)
        btnHome1.Name = "btnHome1"
        btnHome1.Size = New Size(56, 58)
        btnHome1.SizeMode = PictureBoxSizeMode.Zoom
        btnHome1.TabIndex = 16
        btnHome1.TabStop = False
        ' 
        ' Label1
        ' 
        Label1.AutoSize = True
        Label1.BackColor = Color.Transparent
        Label1.Font = New Font("Rockwell", 24F, FontStyle.Bold, GraphicsUnit.Point, CByte(0))
        Label1.Location = New Point(79, 22)
        Label1.Name = "Label1"
        Label1.Size = New Size(201, 39)
        Label1.TabIndex = 21
        Label1.Text = "Notification"
        ' 
        ' Label2
        ' 
        Label2.AutoSize = True
        Label2.Font = New Font("STHupo", 9.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(134))
        Label2.Location = New Point(248, 116)
        Label2.Name = "Label2"
        Label2.Size = New Size(60, 13)
        Label2.TabIndex = 22
        Label2.Text = "7 : 15 pm"
        ' 
        ' PictureBox2
        ' 
        PictureBox2.Image = CType(resources.GetObject("PictureBox2.Image"), Image)
        PictureBox2.Location = New Point(49, 107)
        PictureBox2.Name = "PictureBox2"
        PictureBox2.Size = New Size(268, 84)
        PictureBox2.TabIndex = 23
        PictureBox2.TabStop = False
        ' 
        ' PictureBox3
        ' 
        PictureBox3.Image = CType(resources.GetObject("PictureBox3.Image"), Image)
        PictureBox3.Location = New Point(49, 200)
        PictureBox3.Name = "PictureBox3"
        PictureBox3.Size = New Size(268, 84)
        PictureBox3.TabIndex = 24
        PictureBox3.TabStop = False
        ' 
        ' PictureBox4
        ' 
        PictureBox4.Image = CType(resources.GetObject("PictureBox4.Image"), Image)
        PictureBox4.Location = New Point(49, 290)
        PictureBox4.Name = "PictureBox4"
        PictureBox4.Size = New Size(268, 84)
        PictureBox4.TabIndex = 25
        PictureBox4.TabStop = False
        ' 
        ' PictureBox5
        ' 
        PictureBox5.Image = CType(resources.GetObject("PictureBox5.Image"), Image)
        PictureBox5.Location = New Point(49, 380)
        PictureBox5.Name = "PictureBox5"
        PictureBox5.Size = New Size(268, 84)
        PictureBox5.TabIndex = 26
        PictureBox5.TabStop = False
        ' 
        ' PictureBox6
        ' 
        PictureBox6.Image = CType(resources.GetObject("PictureBox6.Image"), Image)
        PictureBox6.Location = New Point(49, 470)
        PictureBox6.Name = "PictureBox6"
        PictureBox6.Size = New Size(268, 84)
        PictureBox6.TabIndex = 27
        PictureBox6.TabStop = False
        ' 
        ' Label3
        ' 
        Label3.AutoSize = True
        Label3.Font = New Font("STHupo", 9.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(134))
        Label3.Location = New Point(248, 479)
        Label3.Name = "Label3"
        Label3.Size = New Size(64, 13)
        Label3.TabIndex = 28
        Label3.Text = "10. 41 am"
        ' 
        ' Label4
        ' 
        Label4.AutoSize = True
        Label4.Font = New Font("STHupo", 9.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(134))
        Label4.Location = New Point(248, 390)
        Label4.Name = "Label4"
        Label4.Size = New Size(63, 13)
        Label4.TabIndex = 29
        Label4.Text = "3 : 53 pm "
        ' 
        ' Label5
        ' 
        Label5.AutoSize = True
        Label5.Font = New Font("STHupo", 9.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(134))
        Label5.Location = New Point(248, 299)
        Label5.Name = "Label5"
        Label5.Size = New Size(60, 13)
        Label5.TabIndex = 30
        Label5.Text = "6 : 01 pm"
        ' 
        ' Label6
        ' 
        Label6.AutoSize = True
        Label6.Font = New Font("STHupo", 9.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(134))
        Label6.Location = New Point(248, 209)
        Label6.Name = "Label6"
        Label6.Size = New Size(60, 13)
        Label6.TabIndex = 31
        Label6.Text = "6 : 30 pm"
        ' 
        ' Label7
        ' 
        Label7.AutoSize = True
        Label7.Font = New Font("STHupo", 9.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(134))
        Label7.Location = New Point(52, 140)
        Label7.Name = "Label7"
        Label7.Size = New Size(260, 26)
        Label7.TabIndex = 32
        Label7.Text = "You have received at RM10 discount voucher" & vbCrLf & " for your next purchase!!!"
        ' 
        ' Label8
        ' 
        Label8.AutoSize = True
        Label8.Font = New Font("STHupo", 9.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(134))
        Label8.Location = New Point(57, 331)
        Label8.Name = "Label8"
        Label8.Size = New Size(251, 13)
        Label8.TabIndex = 33
        Label8.Text = "FLASH SALE -80% on ALL clothing. HURRY !!!"
        ' 
        ' Label9
        ' 
        Label9.AutoSize = True
        Label9.Font = New Font("STHupo", 9.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(134))
        Label9.Location = New Point(63, 417)
        Label9.Name = "Label9"
        Label9.Size = New Size(234, 26)
        Label9.TabIndex = 34
        Label9.Text = "Thank You For Purchasing From Us." & vbCrLf & "We sincerely thank you for you support!" & vbCrLf
        ' 
        ' Label10
        ' 
        Label10.AutoSize = True
        Label10.Font = New Font("STHupo", 9.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(134))
        Label10.Location = New Point(65, 236)
        Label10.Name = "Label10"
        Label10.Size = New Size(232, 26)
        Label10.TabIndex = 35
        Label10.Text = "Your order num.23465625242 has been " & vbCrLf & "Shipped By Seller !!!"
        ' 
        ' Label11
        ' 
        Label11.AutoSize = True
        Label11.Font = New Font("STHupo", 9.75F, FontStyle.Regular, GraphicsUnit.Point, CByte(134))
        Label11.Location = New Point(94, 506)
        Label11.Name = "Label11"
        Label11.Size = New Size(167, 26)
        Label11.TabIndex = 36
        Label11.Text = "Important Notice For Your " & vbCrLf & "Order num.21353234134!!!"
        ' 
        ' PictureBox7
        ' 
        PictureBox7.BackColor = Color.Transparent
        PictureBox7.Image = CType(resources.GetObject("PictureBox7.Image"), Image)
        PictureBox7.Location = New Point(342, -1)
        PictureBox7.Name = "PictureBox7"
        PictureBox7.Size = New Size(28, 26)
        PictureBox7.SizeMode = PictureBoxSizeMode.CenterImage
        PictureBox7.TabIndex = 37
        PictureBox7.TabStop = False
        ' 
        ' Notification
        ' 
        AutoScaleDimensions = New SizeF(7F, 15F)
        AutoScaleMode = AutoScaleMode.Font
        ClientSize = New Size(370, 700)
        Controls.Add(PictureBox7)
        Controls.Add(Label11)
        Controls.Add(Label10)
        Controls.Add(Label9)
        Controls.Add(Label8)
        Controls.Add(Label7)
        Controls.Add(Label6)
        Controls.Add(Label5)
        Controls.Add(Label4)
        Controls.Add(Label3)
        Controls.Add(PictureBox6)
        Controls.Add(PictureBox5)
        Controls.Add(PictureBox4)
        Controls.Add(PictureBox3)
        Controls.Add(Label2)
        Controls.Add(Label1)
        Controls.Add(btnCategory1)
        Controls.Add(btnSearch1)
        Controls.Add(btnNotification1)
        Controls.Add(btnProfile1)
        Controls.Add(btnHome1)
        Controls.Add(PictureBox1)
        Controls.Add(btnBack)
        Controls.Add(PictureBox2)
        FormBorderStyle = FormBorderStyle.None
        Name = "Notification"
        StartPosition = FormStartPosition.CenterScreen
        Text = "Form1"
        CType(btnBack, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox1, ComponentModel.ISupportInitialize).EndInit()
        CType(btnCategory1, ComponentModel.ISupportInitialize).EndInit()
        CType(btnSearch1, ComponentModel.ISupportInitialize).EndInit()
        CType(btnNotification1, ComponentModel.ISupportInitialize).EndInit()
        CType(btnProfile1, ComponentModel.ISupportInitialize).EndInit()
        CType(btnHome1, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox2, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox3, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox4, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox5, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox6, ComponentModel.ISupportInitialize).EndInit()
        CType(PictureBox7, ComponentModel.ISupportInitialize).EndInit()
        ResumeLayout(False)
        PerformLayout()
    End Sub

    Friend WithEvents btnBack As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnCategory1 As PictureBox
    Friend WithEvents btnSearch1 As PictureBox
    Friend WithEvents btnNotification1 As PictureBox
    Friend WithEvents btnProfile1 As PictureBox
    Friend WithEvents btnHome1 As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents PictureBox4 As PictureBox
    Friend WithEvents PictureBox5 As PictureBox
    Friend WithEvents PictureBox6 As PictureBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents PictureBox7 As PictureBox
End Class
